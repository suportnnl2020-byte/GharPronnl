importScripts('https://www.gstatic.com/firebasejs/9.22.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.22.0/firebase-messaging-compat.js');

const firebaseConfig = {
    apiKey: "AIzaSyCBa8UmWUB-djAksNNvp14qoCY2y0HISoE",
    authDomain: "gharproindia.firebaseapp.com",
    projectId: "gharproindia",
    storageBucket: "gharproindia.firebasestorage.app",
    messagingSenderId: "374168845849",
    appId: "1:374168845849:web:36aeca99558917c34ff488"
};

firebase.initializeApp(firebaseConfig);
const messaging = firebase.messaging();

messaging.onBackgroundMessage(function(payload) {
    const notificationTitle = payload.notification?.title || 'GharPro Update';
    const notificationOptions = {
        body: payload.notification?.body || 'New update from GharPro',
        icon: '/icons/icon-192.png',
        badge: '/icons/icon-72.png',
        vibrate: [200, 100, 200],
        data: {
            click_action: payload.data?.click_action || '/'
        }
    };
    self.registration.showNotification(notificationTitle, notificationOptions);
});